run this command in console
      mvn clean install
   OR
      mvn clean install package
run this command in console
     mvn spring-boot:run

try to access this url(For employee list)
    http://localhost:8080/list

For more detail, visit here:
      
